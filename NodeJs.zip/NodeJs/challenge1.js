const args = process.argv.slice(2);
const joinedArgs = args.join('-');
console.log(`Hello-${joinedArgs}`);
