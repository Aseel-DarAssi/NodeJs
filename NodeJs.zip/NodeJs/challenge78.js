import { Worker, MessageChannel } from 'worker_threads';

const { port1, port2 } = new MessageChannel();

const worker = new Worker(`
  const { parentPort } = require('worker_threads');
  parentPort.on('message', msg => parentPort.postMessage(msg*2));
`, { eval: true });

port1.on('message', msg => console.log('Received from worker:', msg));
port2.postMessage(10);
