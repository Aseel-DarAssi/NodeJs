import { User } from './types86';

const u: User = { id:1, email:'a@b.com' };
console.log(u);
