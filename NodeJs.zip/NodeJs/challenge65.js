import express from 'express';
import multer from 'multer';

const app = express();
const upload = multer({ dest: 'uploads/' });

app.post('/avatar', upload.single('avatar'), (req, res) => {
    res.send(`Uploaded: ${req.file.originalname}`);
});

app.listen(3000);
