async function safe(fn) {
    try {
        const data = await fn();
        return [null, data];
    } catch (err) {
        return [err, null];
    }
}

// example
const task = async () => {
    return 42;
};

const [err, data] = await safe(task);
console.log(err, data);
 