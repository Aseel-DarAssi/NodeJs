import mongoose from 'mongoose';
import { User } from './userSchema.js';

await mongoose.connect('mongodb://localhost:27017/app');

// create
const u = await User.create({ email: 'a@example.com' });

// find
const found = await User.findOne({ email: 'a@example.com' });

// update
await User.updateOne({ email: 'a@example.com' }, { email: 'b@example.com' });

// delete
await User.deleteOne({ email: 'b@example.com' });

console.log('Done');
