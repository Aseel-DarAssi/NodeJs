import http from 'http';
import { URL } from 'url';

const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');

    if (url.pathname === '/greet') {
        const name = url.searchParams.get('name');
        res.end(`Hello, ${name}`);
    }
});

server.listen(3000);
