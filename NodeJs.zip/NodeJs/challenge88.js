import express from 'express';
import { z } from 'zod';

const schema = z.object({ email: z.string().email(), age: z.number().int() });
const app = express();
app.use(express.json());

app.post('/user', (req, res) => {
    const result = schema.safeParse(req.body);
    if (!result.success) return res.status(400).json(result.error.format());
    res.json(result.data);
});

app.listen(3000);
