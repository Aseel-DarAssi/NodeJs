import { ApolloServer, gql } from 'apollo-server';
// ApolloServer => لإنشاء سيرفر GraphQL
// gql => لكتابة Schema بصيغة GraphQL

const typeDefs = gql`
type Query { hello: String }
type Mutation { add(a: Int, b: Int): Int }
`;

const resolvers = {
  Query: { hello: () => 'Hello' },
  Mutation: { add: (_, {a, b}) => a + b }
};

const server = new ApolloServer({ typeDefs, resolvers });
server.listen(3000).then(({ url }) => console.log('Server:', url));
// port 3000
