import fs from 'fs/promises';

const [a, b] = await Promise.all([
    fs.readFile('a.txt'),
    fs.readFile('b.txt')
]);

console.log(a.length + b.length);
