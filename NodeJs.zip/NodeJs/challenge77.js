import { Worker } from 'worker_threads';

const worker = new Worker(`
  const { parentPort } = require('worker_threads');
  function fib(n) { return n < 2 ? n : fib(n-1)+fib(n-2); }
  parentPort.postMessage(fib(20));
`, { eval: true });

worker.on('message', msg => console.log('Fib result:', msg));
