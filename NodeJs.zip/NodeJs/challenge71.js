import { Transform } from 'stream';
import fs from 'fs';

const upper = new Transform({
    transform(chunk, enc, cb) {
        cb(null, chunk.toString().toUpperCase());
    }
});

fs.createReadStream('input.txt')
  .pipe(upper)
  .pipe(fs.createWriteStream('output.txt'))
  .on('finish', () => console.log('Transformed!'));
