import fs from 'fs';

const readable = fs.createReadStream('big.txt');
const writable = fs.createWriteStream('big_copy.txt');

readable.on('data', (chunk) => {
    if (!writable.write(chunk)) {
        readable.pause();
    }
});

writable.on('drain', () => {
    readable.resume();
});

readable.on('end', () => {
    writable.end();
});
