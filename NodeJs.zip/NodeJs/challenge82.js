import { Queue, Worker } from 'bullmq';

const queue = new Queue('email');

new Worker('email', async job => console.log('Processing', job.name), { concurrency: 5 });

queue.add('send', { to: 'user@example.com' });
