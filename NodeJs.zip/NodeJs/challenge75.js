import { exec } from 'child_process';

exec('ls -la', (err, stdout) => {
    if (err) throw err;
    console.log('Output length:', stdout.length);
});
