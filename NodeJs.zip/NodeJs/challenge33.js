import fs from 'fs/promises';

Promise.race([
    fs.readFile('a.txt'),
    fs.readFile('missing.txt')
])
.then(() => console.log('race resolved'))
.catch(() => console.log('race rejected'));

Promise.allSettled([
    fs.readFile('a.txt'),
    fs.readFile('missing.txt')
])
.then(results => {
    console.log(results);
});
