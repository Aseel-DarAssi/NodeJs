import express from 'express';
const app = express();

let cache = { data: null, time: 0 };

app.get('/data', (req, res) => {
    if (Date.now() - cache.time < 5000) return res.send(cache.data);
    cache.data = 'Fresh data ' + Date.now();
    cache.time = Date.now();
    res.send(cache.data);
});

app.listen(3000);
