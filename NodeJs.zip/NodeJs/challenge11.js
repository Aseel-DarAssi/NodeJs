import { URL } from 'url';

const myUrl = new URL('https://example.com/api?x=10&y=test');
console.log('x =', myUrl.searchParams.get('x'));
console.log('y =', myUrl.searchParams.get('y'));
