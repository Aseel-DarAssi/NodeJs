userSchema.index({ email: 1, createdAt: -1 });
