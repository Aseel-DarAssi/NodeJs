import fetch from 'node-fetch';

async function callB(a, b) {
    for (let i=0; i<3; i++) {
        try {
            const res = await fetch(`http://localhost:3001/sum?a=${a}&b=${b}`);
            return await res.json();
        } catch(e) { if (i===2) throw e; }
    }
}
