import express from 'express';

const app = express();

app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        console.log(req.method, req.url, Date.now() - start);
    });
    next();
});

app.get('/', (req, res) => {
    res.send('OK');
});

app.listen(3000);
