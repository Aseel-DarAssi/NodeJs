function runMiddlewares(req, res, middlewares) {
    let i = 0;

    function next() {
        const mw = middlewares[i++];
        if (mw) mw(req, res, next);
    }

    next();
}

// example
const middlewares = [
    (req, res, next) => { console.log('one'); next(); },
    (req, res, next) => { console.log('two'); next(); }
];

runMiddlewares({}, {}, middlewares);
