import express from 'express';
import jwt from 'jsonwebtoken';

const app = express();

function verifyToken(req, res, next) {
    const auth = req.headers.authorization;
    if (!auth) return res.status(401).send('No token');
    const token = auth.split(' ')[1];
    try {
        req.user = jwt.verify(token, 'secret');
        next();
    } catch {
        res.status(401).send('Invalid token');
    }
}

app.get('/secure', verifyToken, (req, res) => res.send(`Hello user ${req.user.userId}`));
app.listen(3000);
