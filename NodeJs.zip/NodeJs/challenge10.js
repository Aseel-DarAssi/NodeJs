import path from 'path';

const __dirname = '/usr/app';
const filePath = path.join(__dirname, 'assets', 'img', 'logo.png');
console.log(path.normalize(filePath));
