const buf = Buffer.from('Hello', 'utf8');
console.log(buf.toString('hex'));
