import bcrypt from 'bcrypt';

const password = 'mypassword';
const hashed = await bcrypt.hash(password, 10);
console.log('Hashed:', hashed);

const match = await bcrypt.compare('mypassword', hashed);
console.log('Match?', match);
