const base64 = Buffer.from('Hello World').toString('base64');
console.log('Base64:', base64);

const utf8 = Buffer.from(base64, 'base64').toString('utf-8');
console.log('UTF-8:', utf8);
