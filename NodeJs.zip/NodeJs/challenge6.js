import fs from 'fs';

fs.readFile('file.txt', 'utf-8', (err, data) => {
    if (err) throw err;
    console.log(data);

    // Guarantee after-read logs after read
    setImmediate(() => console.log('after read'));
});
