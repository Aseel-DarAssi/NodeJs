import { add } from './math.js';

console.log(add(3, 4));
