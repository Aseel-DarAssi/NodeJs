const { add } = require('./math');

console.log(add(3, 4));
