import EventEmitter from 'events';

const emitter = new EventEmitter();
let count = 0;

emitter.on('ping', () => {
    count++;
    console.log('ping received, count =', count);
});

emitter.emit('ping');
emitter.emit('ping');
