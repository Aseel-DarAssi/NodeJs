import express from 'express';
const app = express();

const feature = process.env.FEATURE_NEW_HOME === 'true';

app.get('/', (req, res) => res.send(feature ? 'New Home' : 'Old Home'));
app.listen(3000);
