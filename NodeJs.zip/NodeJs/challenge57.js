import express from 'express';
import xss from 'xss';

const app = express();

app.get('/', (req, res) => {
    const name = req.query.name || '';
    res.send(`Hello, ${xss(name)}`);
});

app.listen(3000);
