import express from 'express';
import { Server } from 'socket.io';
import http from 'http';

const app = express();
const server = http.createServer(app);
const io = new Server(server);

io.on('connection', socket => {
    socket.on('join', room => socket.join(room));
    socket.on('msg', ({ room, msg }) => io.to(room).emit('msg', msg));
});

server.listen(3000);
