import dotenv from 'dotenv';
import { z } from 'zod';
dotenv.config();

const schema = z.object({ NODE_ENV: z.enum(['dev','test','prod']) });
const env = schema.parse(process.env);
console.log('Env ok', env.NODE_ENV);
