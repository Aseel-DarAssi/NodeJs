import { setTimeout } from 'timers/promises';

const controller = new AbortController();
const signal = controller.signal;

setTimeout(5000, null, { signal })
    .then(() => console.log('Done'))
    .catch(err => console.log('Aborted'));

controller.abort();
