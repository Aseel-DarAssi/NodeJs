import express from 'express';

const app = express();
app.use(express.json());

let todos = [];
let id = 1;

app.get('/todos', (req, res) => res.json(todos));
app.post('/todos', (req, res) => {
    const todo = { id: id++, text: req.body.text };
    todos.push(todo);
    res.json(todo);
});
app.put('/todos/:id', (req, res) => {
    const todo = todos.find(t => t.id == req.params.id);
    if (todo) todo.text = req.body.text;
    res.json(todo || {});
});
app.delete('/todos/:id', (req, res) => {
    todos = todos.filter(t => t.id != req.params.id);
    res.json({ deleted: true });
});

app.listen(3000);
