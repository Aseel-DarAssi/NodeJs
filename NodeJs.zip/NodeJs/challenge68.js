import dotenv from 'dotenv';
dotenv.config();

const env = process.env.NODE_ENV;
if (!['dev','test','prod'].includes(env)) throw new Error('Invalid NODE_ENV');
console.log('Environment:', env);
