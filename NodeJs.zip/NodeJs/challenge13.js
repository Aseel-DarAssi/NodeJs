import EventEmitter from 'events';

const emitter = new EventEmitter();

function log1() { console.log('log1'); }
function log2() { console.log('log2'); }

emitter.on('event', log1);
emitter.on('event', log2);

emitter.off('event', log2);

emitter.emit('event');
