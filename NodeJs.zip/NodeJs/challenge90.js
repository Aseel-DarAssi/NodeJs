import express from 'express';
import swaggerUi from 'swagger-ui-express';

const app = express();
const swaggerDocument = { openapi:"3.0.0", info:{title:"API", version:"1.0"}, paths:{} };

app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.listen(3000);
