import express from 'express';

const app = express();

app.get('/', (req, res) => {
    throw new Error('Something went wrong');
});

// centralized error handler
app.use((err, req, res, next) => {
    res.status(500).json({ message: err.message });
});

app.listen(3000);
