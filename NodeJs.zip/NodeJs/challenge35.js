async function retry(fn, times) {
    let lastError;

    for (let i = 0; i < times; i++) {
        try {
            return await fn();
        } catch (e) {
            lastError = e;
        }
    }
    throw lastError;
}

// example
let count = 0;
const unstable = async () => {
    count++;
    if (count < 3) throw new Error('fail');
    return 'success';
};

console.log(await retry(unstable, 5));
