import fs from 'fs';

// synchronous
const dataSync = fs.readFileSync('data.txt');
console.log('Sync bytes count:', dataSync.length);

// asynchronous
fs.readFile('data.txt', (err, dataAsync) => {
    if (err) throw err;
    console.log('Async bytes count:', dataAsync.length);
});
