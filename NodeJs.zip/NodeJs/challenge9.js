import { writeFile } from 'fs/promises';
import path from 'path';

const filePath = path.join('.', 'result.json');

async function writeJSON() {
    await writeFile(filePath, JSON.stringify({ ok: true }, null, 2));
    console.log('JSON written to result.json');
}

writeJSON();
