import express from 'express';

const app = express();
app.use(express.json());

app.post('/users', (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email required' });
    res.json({ message: 'User created', email });
});

app.listen(3000);
