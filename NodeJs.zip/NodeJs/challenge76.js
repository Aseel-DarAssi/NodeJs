import { spawn } from 'child_process';

const child = spawn('node', ['-v']);
child.stdout.on('data', data => process.stdout.write(data));
