import express from 'express';
import request from 'supertest';

const app = express();
app.get('/health', (req,res)=>res.json({ok:true}));

test('GET /health', async () => {
  await request(app).get('/health').expect(200).expect({ok:true});
});
