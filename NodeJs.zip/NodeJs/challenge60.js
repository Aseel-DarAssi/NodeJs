import express from 'express';
import jwt from 'jsonwebtoken';
const app = express();
app.use(express.json());

app.post('/login', (req, res) => {
    const { user, pass } = req.body;
    if (user === 'admin' && pass === '123') {
        const token = jwt.sign({ userId: 1 }, 'secret', { algorithm: 'HS256' });
        res.json({ token });
    } else res.status(401).send('Unauthorized');
});

app.listen(3000);
