import mongoose from 'mongoose';

await mongoose.connect('mongodb://localhost:27017/app');
const session = await mongoose.startSession();
session.startTransaction();

try {
    await mongoose.connection.collection('test').insertOne({ a: 1 }, { session });
    await mongoose.connection.collection('test').insertOne({ a: 2 }, { session });
    await session.commitTransaction();
    console.log('Committed');
} catch(e) {
    await session.abortTransaction();
} finally {
    session.endSession();
}
