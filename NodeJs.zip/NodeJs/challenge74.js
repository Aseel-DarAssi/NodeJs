import cluster from 'cluster';
import http from 'http';
import os from 'os';

if (cluster.isMaster) {
    const cpus = os.cpus().length;
    for (let i = 0; i < cpus; i++) cluster.fork();
} else {
    http.createServer((req, res) => res.end('Hello')).listen(3000);
    console.log('Worker PID:', process.pid);
}
