import fs from 'fs';
import readline from 'readline';

const fileStream = fs.createReadStream('input.txt');
let lineCount = 0;

const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
});

rl.on('line', () => {
    lineCount++;
});

rl.on('close', () => {
    console.log('Number of lines:', lineCount);
});
