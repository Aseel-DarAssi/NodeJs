import Redis from 'ioredis';
const redis = new Redis();

async function getPosts() {
    const cached = await redis.get('posts');
    if (cached) return JSON.parse(cached);
    const dbPosts = [{id:1}]; // pretend DB
    await redis.set('posts', JSON.stringify(dbPosts), 'EX', 60);
    return dbPosts;
}
