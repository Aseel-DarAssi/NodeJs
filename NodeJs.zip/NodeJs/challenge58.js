import express from 'express';
const app = express();

const ipCounts = {};
const limit = 60; // per minute

app.use((req, res, next) => {
    const ip = req.ip;
    ipCounts[ip] = ipCounts[ip] || 0;
    ipCounts[ip]++;
    setTimeout(() => ipCounts[ip]--, 60000);
    if (ipCounts[ip] > limit) return res.status(429).send('Too many requests');
    next();
});

app.get('/', (req, res) => res.send('Hello'));
app.listen(3000);
