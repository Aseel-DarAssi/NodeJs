import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

const users = await prisma.user.findMany({
  where: { email: { contains: '@example.com' } }
});

console.log(users);
