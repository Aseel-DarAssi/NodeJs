import fs from 'fs';
jest.mock('fs');

fs.readFile.mockImplementation((path, cb) => cb(null, 'hello'));

test('readFile mock', done => {
  fs.readFile('a.txt', (err,data)=> {
    expect(data).toBe('hello');
    done();
  });
});
