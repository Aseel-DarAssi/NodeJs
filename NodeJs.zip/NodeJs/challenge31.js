import fs from 'fs/promises';

const data = await fs.readFile('a.txt');
console.log(data.length);
