import { performance, PerformanceObserver } from 'perf_hooks';

const obs = new PerformanceObserver((list) => console.log(list.getEntries()[0].duration));
obs.observe({ entryTypes: ['measure'] });

performance.mark('start');
setTimeout(() => {
    performance.mark('end');
    performance.measure('timeoutDuration', 'start', 'end');
}, 100);
