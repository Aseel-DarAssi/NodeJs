import express from 'express';
import cookieParser from 'cookie-parser';

const app = express();
app.use(cookieParser('secret'));

app.get('/set', (req, res) => {
    res.cookie('sid', '123', { signed: true });
    res.send('Cookie set');
});

app.get('/read', (req, res) => {
    res.send(req.signedCookies.sid);
});

app.listen(3000);
