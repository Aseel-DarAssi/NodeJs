import fs from 'fs';

fs.writeFileSync('out.txt', 'Hello');

fs.appendFileSync('out.txt', ' World');

console.log('File updated!');
