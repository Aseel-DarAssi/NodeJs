import express from 'express';
import mongoose from 'mongoose';

const app = express();
const server = app.listen(3000);
await mongoose.connect('mongodb://localhost:27017/app');

process.on('SIGINT', async () => {
    console.log('Shutting down...');
    server.close(() => console.log('HTTP closed'));
    await mongoose.connection.close();
    process.exit(0);
});
