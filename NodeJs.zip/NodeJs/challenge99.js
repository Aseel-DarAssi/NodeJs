import Redis from 'ioredis';
const redis = new Redis();
const limit = 10; // burst
const refill = 1000; // ms

async function allow(ip){
  const key = `rate:${ip}`;
  let tokens = await redis.get(key);
  tokens = tokens ? parseInt(tokens) : limit;
  if (tokens>0){
    await redis.set(key, tokens-1, 'PX', refill);
    return true;
  }
  return false;
}
