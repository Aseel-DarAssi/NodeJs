import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({ status: String, total: Number });
const Order = mongoose.model('Order', orderSchema);

await mongoose.connect('mongodb://localhost:27017/app');

const result = await Order.aggregate([
    { $group: { _id: '$status', total: { $sum: '$total' } } }
]);

console.log(result);
