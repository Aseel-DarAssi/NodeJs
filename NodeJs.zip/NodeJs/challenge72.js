import fs from 'fs';
import readline from 'readline';

const rl = readline.createInterface({
    input: fs.createReadStream('data.csv')
});

rl.on('line', line => {
    const [name, age] = line.split(',');
    console.log(JSON.stringify({ name, age }));
});
